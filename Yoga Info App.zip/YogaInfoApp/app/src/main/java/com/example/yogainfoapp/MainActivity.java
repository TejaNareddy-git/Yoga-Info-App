package com.example.yogainfoapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Make sure system bars are respected
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(true);
        }

        // Root layout using FrameLayout to layer background + content
        FrameLayout rootLayout = new FrameLayout(this);

        // Background image
        ImageView bgImageView = new ImageView(this);
        bgImageView.setImageResource(R.drawable.background_image); // Replace with your image name
        bgImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgImageView.setAlpha(0.3f); // Slight transparency

        // Layout to hold cards
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setGravity(Gravity.CENTER_HORIZONTAL);

        // Add cards
        mainLayout.addView(createCard("Yoga Exercises", YogaActivity.class, "#34677d"));
        mainLayout.addView(createCard("Healthy Diet", DietActivity.class, "#F48FB1"));
        mainLayout.addView(createCard("Meditation", MeditationActivity.class, "#26A69A"));

        // LayoutParams to center content
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
        );
        mainLayout.setLayoutParams(layoutParams);

        // Handle safe area
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            rootLayout.setOnApplyWindowInsetsListener((v, windowInsets) -> {
                Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars());
                mainLayout.setPadding(32, insets.top + 32, 32, insets.bottom + 32);
                return windowInsets;
            });
        } else {
            mainLayout.setPadding(32, 80, 32, 32);
        }

        // Add background and content to root
        rootLayout.addView(bgImageView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        rootLayout.addView(mainLayout);

        setContentView(rootLayout);
    }

    private MaterialCardView createCard(String titleText, Class<?> activityToOpen, String backgroundColorHex) {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardElevation(12f);
        card.setRadius(30f);
        card.setUseCompatPadding(true);
        card.setCardBackgroundColor(Color.parseColor(backgroundColorHex));

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, 40);
        card.setLayoutParams(cardParams);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(24f);
        title.setPadding(24, 24, 24, 24);
        title.setTextColor(Color.WHITE);

        card.addView(title);
        card.setOnClickListener(v -> startActivity(new Intent(this, activityToOpen)));

        return card;
    }
}
