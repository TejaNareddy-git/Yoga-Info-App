package com.example.yogainfoapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class YogaActivity extends AppCompatActivity {

    String[][] yogaData = {
            {"Tadasana", "Improves posture, strengthens thighs, knees, and ankles.", "https://youtu.be/3UdD38Pt2-c?si=fn07bfgm2bRMxUq-"},
            {"Vrikshasana", "Improves balance and stability in the legs.", "https://www.youtube.com/watch?v=VaoV1PrYft4"},
            {"Bhujangasana", "Stretches chest, shoulders, and abdomen.", "https://youtu.be/-HgeZztTSec?si=Jzc_dBXIKNXGIK4h"},
            {"Downward Dog", "Strengthens arms and legs, stretches the back.", "https://youtu.be/ayQoxw8sRTk?si=AbTHkOa2llEMni4V"},
            {"Balasana", "Relieves stress and fatigue, gently stretches the spine.", "https://youtu.be/2MJGg-dUKh0?si=DKRxKfpJtrJ-oQlw"},
            {"Trikonasana", "Stretches legs and torso, improves digestion.", "https://www.youtube.com/watch?v=EmeTZGr_R5Q"},
            {"Paschimottanasana", "Relieves stress and calms the brain.", "https://youtu.be/T8sgVyF4Ux4?si=dBdl7mrlEAGAz7B3"},
            {"Bridge Pose", "Strengthens back and glutes.", "https://youtu.be/XUcAuYd7VU0?si=T73TUZhGr1vM-Vfc"},
            {"Chair Pose", "Strengthens thighs and improves focus.", "https://youtu.be/qQZOlIHMlmA?si=CbpsqCODacepjh2G"},
            {"Cat-Cow", "Improves flexibility and posture.", "https://youtu.be/vuyUwtHl694?si=pqSd7jT3lu5LvEPA"} // This one is already correct
    };
    String[] cardColors = {
            "#34677d", "#34677d", "#34677d", "#34677d", "#34677d",
            "#34677d", "#34677d", "#34677d", "#34677d", "#34677d"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout rootLayout = new FrameLayout(this);

        ImageView bgImageView = new ImageView(this);
        bgImageView.setImageResource(R.drawable.background_image);
        bgImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgImageView.setAlpha(0.3f);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            scrollView.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets systemInsets = insets.getInsets(WindowInsets.Type.systemBars());
                layout.setPadding(32, systemInsets.top + 32, 32, systemInsets.bottom + 32);
                return insets;
            });
        }

        for (int i = 0; i < yogaData.length; i++) {
            String[] pose = yogaData[i];
            layout.addView(createYogaCard(pose[0], pose[1], pose[2], cardColors[i % cardColors.length]));
        }

        scrollView.addView(layout);

        rootLayout.addView(bgImageView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        rootLayout.addView(scrollView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(rootLayout);
    }

    private MaterialCardView createYogaCard(String titleText, String description, String youtubeUrl, String colorHex) {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardElevation(8f);
        card.setRadius(25f);
        card.setUseCompatPadding(true);
        card.setCardBackgroundColor(Color.parseColor(colorHex));

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, 24);
        card.setLayoutParams(cardParams);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(20f);
        title.setPadding(24, 24, 24, 24);
        title.setTextColor(Color.WHITE);

        card.addView(title);

        card.setOnClickListener(v -> showYogaInfoDialog(titleText, description, youtubeUrl));

        return card;
    }

    private void showYogaInfoDialog(String title, String description, String youtubeUrl) {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_yoga_info, null);

        TextView descriptionText = dialogView.findViewById(R.id.textDescription);
        TextView youtubeLinkText = dialogView.findViewById(R.id.textYoutubeLink);

        descriptionText.setText(description);
        youtubeLinkText.setText("Watch Video");

        youtubeLinkText.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(youtubeUrl));
            startActivity(intent);
        });

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(dialogView)
                .setPositiveButton("OK", null)
                .show();
    }
}
