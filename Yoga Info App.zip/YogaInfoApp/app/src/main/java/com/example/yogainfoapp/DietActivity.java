package com.example.yogainfoapp;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class DietActivity extends AppCompatActivity {

    String[][] dietData = {
            {"Spinach", "Rich in iron and antioxidants. Helps improve blood health, boosts immunity, supports eye health, and promotes healthy skin. Contains vitamins A, C, and K."},
            {"Banana", "Good source of energy and potassium. Helps regulate blood pressure, supports heart health, aids digestion with dietary fiber, and reduces muscle cramps."},
            {"Almonds", "High in protein and healthy fats. Promote heart health, help maintain weight, improve brain function, and provide vitamin E and magnesium."},
            {"Oats", "Good for digestion and fiber. Helps lower cholesterol, stabilizes blood sugar, promotes satiety for weight management, and supports gut health."},
            {"Greek Yogurt", "Supports gut health and muscle repair. Rich in probiotics, calcium, and protein. Aids digestion, strengthens bones, and helps muscle recovery post-exercise."},
            {"Sweet Potato", "High in fiber and complex carbs. Provides sustained energy, improves gut health, rich in beta-carotene (vitamin A), supports immune function and vision."},
            {"Chia Seeds", "Packed with fiber and omega-3 fatty acids. Help reduce inflammation, improve heart health, support digestion, and provide antioxidants and minerals like calcium."},
            {"Avocado", "Supports heart and joint health. High in healthy monounsaturated fats, vitamins E and C, potassium, and fiber. Helps reduce cholesterol and improve skin elasticity."}
    };

    String[] cardColors = {
            "#F48FB1", "#F48FB1", "#F48FB1", "#F48FB1", "#F48FB1",
            "#F48FB1", "#F48FB1", "#F48FB1"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Root FrameLayout to stack background image + scrollview
        FrameLayout rootLayout = new FrameLayout(this);

        // Background ImageView
        ImageView bgImageView = new ImageView(this);
        bgImageView.setImageResource(R.drawable.background_image);  // your PNG image in drawable folder
        bgImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgImageView.setAlpha(0.3f);  // optional transparency for readability

        // ScrollView with cards
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.TRANSPARENT); // transparent to show bg image

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);

        // Handle system window insets for padding
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            scrollView.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets systemInsets = insets.getInsets(WindowInsets.Type.systemBars());
                layout.setPadding(32, systemInsets.top + 32, 32, systemInsets.bottom + 32);
                return insets;
            });
        }

        // Add diet cards
        for (int i = 0; i < dietData.length; i++) {
            String[] food = dietData[i];
            layout.addView(createDietCard(food[0], food[1], cardColors[i % cardColors.length]));
        }

        scrollView.addView(layout);

        // Add views to root FrameLayout
        rootLayout.addView(bgImageView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        rootLayout.addView(scrollView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(rootLayout);
    }

    private MaterialCardView createDietCard(String titleText, String description, String colorHex) {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardElevation(8f);
        card.setRadius(25f);
        card.setUseCompatPadding(true);
        card.setCardBackgroundColor(Color.parseColor(colorHex));

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, 24);
        card.setLayoutParams(cardParams);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(20f);
        title.setPadding(24, 24, 24, 24);
        title.setTextColor(Color.WHITE);

        card.addView(title);

        card.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(titleText)
                .setMessage(description)
                .setPositiveButton("OK", null)
                .show());

        return card;
    }
}
