package com.example.yogainfoapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class MeditationActivity extends AppCompatActivity {

    String[][] meditationData = {
            {"Mindfulness Meditation", "Focus on your breath and be aware of the present moment.",
                    "https://www.youtube.com/watch?v=wfDTp2GogaQ"},
            {"Loving-Kindness Meditation", "Cultivate feelings of compassion and love towards yourself and others.",
                    "https://www.youtube.com/watch?v=sz7cpV7ERsM"},
            {"Body Scan", "Gradually focus attention on different parts of your body.",
                    "https://www.youtube.com/watch?v=zsCVqFr6i08"},
            {"Transcendental Meditation", "Use a mantra or repetitive sound to calm the mind.",
                    "https://www.youtube.com/watch?v=FTxyu9p20oA"},
            {"Zen Meditation", "Sit quietly and observe your thoughts without attachment.",
                    "https://www.youtube.com/watch?v=Z9rFzIj7GsQ"},
            {"Guided Meditation", "Listen to a guide who leads you through visualization.",
                    "https://www.youtube.com/watch?v=inpok4MKVLM"}
    };

    String[] cardColors = {
            "#26A69A", "#26A69A", "#26A69A", "#26A69A", "#26A69A", "#26A69A"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Root FrameLayout to hold background and content
        FrameLayout rootLayout = new FrameLayout(this);

        // Background Image
        ImageView backgroundImage = new ImageView(this);
        backgroundImage.setImageResource(R.drawable.background_image); // ✅ Add your image in res/drawable
        backgroundImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backgroundImage.setAlpha(0.3f); // Optional: adjust transparency for readability

        // ScrollView for content
        ScrollView scrollView = new ScrollView(this);

        // LinearLayout to hold meditation cards
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);

        // Handle system bar insets
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            scrollView.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets systemInsets = insets.getInsets(WindowInsets.Type.systemBars());
                layout.setPadding(32, systemInsets.top + 32, 32, systemInsets.bottom + 32);
                return insets;
            });
        }

        // Add meditation cards
        for (int i = 0; i < meditationData.length; i++) {
            String[] meditation = meditationData[i];
            layout.addView(createMeditationCard(meditation[0], meditation[1], meditation[2], cardColors[i % cardColors.length]));
        }

        scrollView.addView(layout);

        // Add views to root layout
        rootLayout.addView(backgroundImage, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        rootLayout.addView(scrollView);

        setContentView(rootLayout);
    }

    private MaterialCardView createMeditationCard(String titleText, String description, String youtubeUrl, String colorHex) {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardElevation(8f);
        card.setRadius(25f);
        card.setUseCompatPadding(true);
        card.setCardBackgroundColor(android.graphics.Color.parseColor(colorHex));

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, 24);
        card.setLayoutParams(cardParams);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(20f);
        title.setPadding(24, 24, 24, 24);
        title.setTextColor(android.graphics.Color.WHITE);

        card.addView(title);

        card.setOnClickListener(v -> showMeditationInfoDialog(titleText, description, youtubeUrl));

        return card;
    }

    private void showMeditationInfoDialog(String title, String description, String youtubeUrl) {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_meditation_info, null);

        TextView descriptionText = dialogView.findViewById(R.id.textDescription);
        TextView youtubeLinkText = dialogView.findViewById(R.id.textYoutubeLink);

        descriptionText.setText(description);
        youtubeLinkText.setText("Watch Video");

        youtubeLinkText.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(youtubeUrl));
            startActivity(intent);
        });

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(dialogView)
                .setPositiveButton("OK", null)
                .show();
    }
}
